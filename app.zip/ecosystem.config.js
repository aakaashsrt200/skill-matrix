module.exports = {
	apps: [
		{
			name: 'SkillMatrix',
			script: './app.js',
			log_file: './server.log',
		},
	],
}
