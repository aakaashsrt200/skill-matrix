const user = require('./modules/user')
const admin = require('./modules/admin')

module.exports = {
	user,
	admin,
}
